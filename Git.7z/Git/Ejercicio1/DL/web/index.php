<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">

    <title>Mi título de página</title>
    <link rel="stylesheet" href="css/layout.css">
  </head>
  <body>

   <h1>Header</h1>
   <p>b*h/2= 200*546= 109.200/2= 54.600.</p>

   <img src="imagenes/increibles.png" width="100px"/>


<nav>
   <ul>
     <li><a href="#">Home</a></li>
     <li><a href="#">Nuestro equipo</a></li>
     <li><a href="#">Projectos</a></li>
     <li><a href="#">Contacto</a></li>
   </ul>
</nav>

  <h2>Cabecera de artículo</h2>

  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Donec a diam
     lectus. Set sit amet ipsum mauris. Maecenas congue ligula as quam viverra
     nec consectetur ant hendrerit. Donec et mollis dolor. Praesent et diam eget
     libero egestas mattis sit amet vitae augue. Nam tincidunt congue enim, ut
     porta lorem lacinia consectetur.</p>

  <h3>Subsección</h3>

  <p>Donec ut librero sed accu vehicula ultricies a non tortor. Lorem ipsum
     dolor sit amet, consectetur adipisicing elit. Aenean ut gravida lorem.
     Ut turpis felis, pulvinar a semper sed, adipiscing id dolor.</p>

  <p>Pelientesque auctor nisi id magna consequat sagittis. Curabitur dapibus,
     enim sit amet elit pharetra tincidunt feugiat nist imperdiet. Ut convallis
      libero in urna ultrices accumsan. Donec sed odio eros.</p>

  <h3>Otra subsección</h3>

  <p>Donec viverra mi quis quam pulvinar at malesuada arcu rhoncus. Cum soclis
     natoque penatibus et manis dis parturient montes, nascetur ridiculus mus.
     In rutrum accumsan ultricies. Mauris vitae nisi at sem facilisis semper
     ac in est.</p>

  <p>Vivamus fermentum semper porta. Nunc diam velit, adipscing ut tristique
     vitae sagittis vel odio. Maecenas convallis ullamcorper ultricied.
     Curabitur ornare, ligula semper consectetur sagittis, nisi diam iaculis
     velit, is fringille sem nunc vet mi.</p>

  <h2>Relacionados</h2>

  <ul>
      <li><a href="#">Con diez cañones por banda</a></li>
      <li><a href="#">Viento en popa a toda vela</a></li>
      <li><a href="#">No corta el mar sino vuela</a></li>
      <li><a href="#">Un velero bergantín</a></li>
      <li><a href="#">Bajel pirata que llaman ...</a></li>
  </ul>

   <p>©Copyright 2050 by nobody. All rights reversed.</p>
  </body>
</html>
